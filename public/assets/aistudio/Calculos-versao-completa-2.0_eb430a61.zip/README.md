# Cálculos — PWA

Aplicativo responsivo e instalável para registrar trabalhos freelancers, calcular horas e acompanhar pagamentos.

## Publicar na Netlify
É um site estático, sem etapa de build. Descompacte o ZIP e publique o conteúdo da pasta `Calculos-PWA` na Netlify, por deploy manual ou repositório Git. Use HTTPS para que a instalação PWA funcione.

## Instalar
- iPhone: abra a URL publicada no Safari → Compartilhar → Adicionar à Tela de Início.
- Android: abra no Chrome → menu ⋮ → Instalar aplicativo / Adicionar à tela inicial.

## Recursos
Login configurado no primeiro acesso; registros com data, profissão, local, atividade, entrada, saída, intervalo, cálculo por hora ou valor fechado; controle separado de recebimento do serviço e vale-transporte (pago ou pendente); histórico filtrável; relatórios mensais; exportação CSV e backup/restauração JSON.

## Importante
Esta versão guarda login e dados no armazenamento local do navegador/dispositivo; não sincroniza automaticamente entre dispositivos. O login é simples, para uso pessoal, e não equivale a autenticação segura de servidor. Proteja seu celular e faça backups. Para sincronização em nuvem, múltiplos usuários ou dados sensíveis, conecte um backend com autenticação segura.

Cálculo por hora = horas líquidas × valor/hora. Horas líquidas descontam o intervalo e aceitam turnos que atravessam meia-noite. Valor pendente do serviço = valor calculado menos valor recebido. O vale-transporte é contabilizado separadamente e só entra no total recebido quando marcado como pago.
